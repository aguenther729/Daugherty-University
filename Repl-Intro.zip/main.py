print ("Hello World!")
x = "hey"
print (x * 3)

name = input("What's your name?")
print("Hello", name)

import matplotlib as mat
import matplotlib.pyplot as plt

plt.plot([1, 2, 4, 8, 16])

plt.savefig('plot.png')